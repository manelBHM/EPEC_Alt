package com.example.demo;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.example.demo.model_metier.Article_produit;
import com.example.demo.model_metier.Bookings_Orders;
import com.example.demo.model_metier.Dvd;
import com.example.demo.model_metier.Shipping_Delivery;
import com.example.demo.model_metier.Users;
import com.example.demo.repository.IArticle_produitRespository;
import com.example.demo.repository.IBookings_OrdersRepository;
import com.example.demo.repository.IDvdRepository;
import com.example.demo.repository.IShipping_DeliveryRepository;
import com.example.demo.repository.IUsersRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {

	
	@Autowired
	IDvdRepository mydvd;
	
	@Autowired
	IUsersRepository utilisateur;
	
	@Autowired
	IBookings_OrdersRepository commande;
	
	@Autowired
	IShipping_DeliveryRepository livraison;
	
	@Autowired
	IArticle_produitRespository article;
	
	
	@Before
	public void setUp() throws Exception {	

	}

	@After
	public void tearDown() throws Exception {

	}
	
	@Test
	public void contextLoads() {
		
		Dvd vandam = new Dvd( 1L, "Jean", "Francais");
		mydvd.save(vandam);
		
		Dvd JCVD = new Dvd( 2L, "Mamadou", "wolof");
		mydvd.save(JCVD);
		
		Dvd familyguy = new Dvd( 3L, "Mackenson", "creole Ayisien");
		mydvd.save(familyguy);
		
		Dvd simpson = new Dvd( 1L, "Jean", "Francais");
		mydvd.save(simpson);
		
		Dvd Jnew = new Dvd( 2L, "Mamadou", "wolof");
		mydvd.save(Jnew);
		
		Dvd fam = new Dvd( 3L, "Mackenson", "creole Ayisien");
		mydvd.save(fam);
		
		
		Users Jeslie = new Users(6L, "JESLIE","connaitpas","jeslie@live.fr","j'ai oublié");
		utilisateur.save(Jeslie);
		
		Users Nahla = new Users(8L, "NAHLA", "Villa","nvilla@gmail.com","Sarah");
		utilisateur.save(Nahla);
		
		
		Bookings_Orders Alien = new Bookings_Orders(10L,10);
		commande.save(Alien);
		
		
		Bookings_Orders Godzilla = new Bookings_Orders(4L,9);
		commande.save(Godzilla);
		
		Shipping_Delivery Maison = new Shipping_Delivery(89L,"Maison");
		livraison.save(Maison);
		
		Shipping_Delivery pointRelais = new Shipping_Delivery(88L,"Point Relais");
		livraison.save(pointRelais);
		
		
		Article_produit panier1 = new Article_produit(45L,50,"5Articles");
		article.save(panier1);
		
				
		Article_produit panier2 = new Article_produit(46L,30,"3Articles");
		article.save(panier2);
		
		
	}

}
