package com.example.demo.api;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model_metier.Dvd;
import com.example.demo.model_metier.Users;
import com.example.demo.repository.IUsersRepository;
@CrossOrigin(value="*")
@RestController
@RequestMapping(value="/api")
public class UserController {

	@Autowired
	IUsersRepository nouv;
	
	@GetMapping(value = "/premium") // @Tracable
	public List<Users> getMesusers() {
	    return nouv.findAll();
		
	    } 
	
	@GetMapping (value="/annonce/{id}")
	public ResponseEntity<?> getMesUsers(@PathVariable Long id) {
		Optional<Users> mesusers = nouv.findById(id);
		if(!mesusers.isPresent())
		return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		return ResponseEntity.ok(mesusers); }
	
	// Ajoute une ressource 
			@PostMapping("/postannonce")
			public ResponseEntity<?> savead(@RequestBody Users mesutilisateurs){
			    return ResponseEntity.ok(nouv.save(mesutilisateurs));
			    //return new ResponseEntity<>(HttpStatus.OK);
			}
	
	
	
	
	
}
