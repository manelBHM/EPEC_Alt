/*package com.example.demo.api;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model_metier.Shipping_Delivery;
import com.example.demo.repository.IShipping_DeliveryRepository;
@CrossOrigin(value="*")
@RestController
@RequestMapping(value="/api")

public class Shipping_DeliveryController {

	@Autowired
	IShipping_DeliveryRepository nouve;
	
	
	@GetMapping(value = "/premium") // @Tracable
	public List<Shipping_Delivery> getMaLivraison() {
	    return nouve.findAll();
		
	    
	 
	    } 

	  @GetMapping (value="/annonce/{id}")
			public ResponseEntity<?> getMaLivraison(@PathVariable Long id) {
				Optional<Shipping_Delivery> MaLivraison = nouve.findById(id);
				if(!MaLivraison.isPresent())
				return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
				return ResponseEntity.ok(MaLivraison); }
}


*/
	

