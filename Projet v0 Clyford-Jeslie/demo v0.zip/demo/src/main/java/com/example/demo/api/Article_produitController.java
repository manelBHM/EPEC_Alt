package com.example.demo.api;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
/*import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.model_metier.Article_produit;
import com.example.demo.repository.IArticle_produitRespository;
@CrossOrigin(value="*")
@RestController
@RequestMapping(value="/api")

public class Article_produitController {

	@Autowired
	IArticle_produitRespository nouvea;
	
	
	@GetMapping(value = "/premium") // @Tracable
	public List<Article_produit> getMonPanier() {
	    return nouvea.findAll();
		
	    
	 
	    } 

	  @GetMapping (value="/annonce/{id}")
			public ResponseEntity<?> getMonPanier(@PathVariable Long id) {
				Optional<Article_produit> MonPanier = nouvea.findById(id);
				if(!MonPanier.isPresent())
				return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
				return ResponseEntity.ok(MonPanier); }
}



	
*/

	

