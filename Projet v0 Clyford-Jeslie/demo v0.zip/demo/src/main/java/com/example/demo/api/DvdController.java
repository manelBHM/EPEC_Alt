package com.example.demo.api;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model_metier.Dvd;
import com.example.demo.repository.IDvdRepository;


@CrossOrigin(value = "*")
@RequestMapping(value = "/api")
@RestController
public class DvdController {
	@Autowired
	IDvdRepository mydvd;
	
//	Create = PUT
//	Retrieve = GET
//	Update = POST
//	Delete = DELETE	

//Ce controlleur concerne l'utilisateur du site

//  Accède à une ressource dans ce cas la liste de tous les utilisateurs
	
	@GetMapping(value = "/premium") // @Tracable
	public List<Dvd> getMondvd() {
	    return mydvd.findAll();
		
	    } 
	
	// Accède à une ressource donc un dvd par son id
		@GetMapping (value="/annonce/{id}")
		public ResponseEntity<?> getMondvd(@PathVariable Long id) {
			Optional<Dvd> mondvd = mydvd.findById(id);
			if(!mondvd.isPresent())
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
			return ResponseEntity.ok(mondvd); }
	
		// Ajoute une ressource 
		@PostMapping("/postannonce")
		public ResponseEntity<?> savead(@RequestBody Dvd mondvd){
		    return ResponseEntity.ok(mydvd.save(mondvd));
		    //return new ResponseEntity<>(HttpStatus.OK);
		}
		
		// Pour supprimer 
		@DeleteMapping(value="/deleteAd/{id}")
		public ResponseEntity<?> deletemondvd(@PathVariable Long id){

			mydvd.deleteById(id);
		    return new ResponseEntity<>(HttpStatus.OK);
		}
	
		
		// Met à jour une ressource complète en la remplaçant par une nouvelle version 
		@PutMapping(value = "/updateannonce/{id}")
		public ResponseEntity<?> updateAd(@PathVariable Long id, @RequestBody Dvd mondvd) {

			Optional<Dvd> adOptional = mydvd.findById(id);
			if (!adOptional.isPresent()) {
				return ResponseEntity.notFound().build();
			}
			mondvd.setId(id);
			mydvd.save(mondvd);
			return ResponseEntity.ok(mondvd);
		}

}
