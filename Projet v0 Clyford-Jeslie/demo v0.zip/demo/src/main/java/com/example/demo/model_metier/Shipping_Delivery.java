package com.example.demo.model_metier;

//import java.time.LocalDateTime;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

//@NoArgsConstructor
@ToString
@Data
@Entity
public class Shipping_Delivery {
	// @Setter(AccessLevel.NONE)
	@Id // pour generer une clé primaire
	@GeneratedValue(strategy = GenerationType.IDENTITY) // // clé primaire générée de façon automatique , La génération
														// de la clé primaire se fera à partir d’une Identité propre au
														// SGBD. Il utilise un type de colonne spéciale à la base de
														// données. Donc une auto-increment
	private Long id;//// long : un entier relatif long (entre -9 223 372 036 854 775 808 et 9 223
					//// 372 036 854 775 807).
	//private LocalDateTime creationDate = LocalDateTime.now();
	
	private String name;
	
	protected Shipping_Delivery() {}

	public Shipping_Delivery(Long id, String name) {
		this.id = id;
		this.name = name;
	}
	
}
