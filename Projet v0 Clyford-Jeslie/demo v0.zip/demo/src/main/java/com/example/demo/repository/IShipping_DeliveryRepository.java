package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model_metier.Shipping_Delivery;
@Repository
public interface IShipping_DeliveryRepository extends JpaRepository<Shipping_Delivery,Long>{

}
