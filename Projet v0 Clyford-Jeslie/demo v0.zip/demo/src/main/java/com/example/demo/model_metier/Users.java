package com.example.demo.model_metier;

//import java.time.LocalDateTime;


import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

//@NoArgsConstructor
@ToString
@Data
@Entity
public class Users {
	
	
	// @Setter(AccessLevel.NONE)
		@Id // pour generer une clé primaire
		@GeneratedValue(strategy = GenerationType.IDENTITY) // // clé primaire générée de façon automatique , La génération
															// de la clé primaire se fera à partir d’une Identité propre au
															// SGBD. Il utilise un type de colonne spéciale à la base de
															// données. Donc une auto-increment
		private Long id;//// long : un entier relatif long (entre -9 223 372 036 854 775 808 et 9 223
						//// 372 036 854 775 807).
		//private LocalDateTime creationDate = LocalDateTime.now();

		/*@NotEmpty
		@NotNull*/
		@Size(min = 1, max = 30)
		private String name;

		
		/*@NotEmpty
		@NotNull*/
		@Size(min = 1, max = 30)
		private String firstname;



		/*@NotEmpty
		@NotNull*/
		@Size(min = 1, max = 50)
		private String mail;


		/*@NotEmpty
		@NotNull*/
		@Size(min = 1, max = 30)
		private String password;

		
		/*@ManyToMany
		private Article_produit articles;

		
		@OneToOne
		private Bookings_Orders fait;
*/
		
		protected Users() {}


		public Users(Long id, @Size(min = 1, max = 30) String name, @Size(min = 1, max = 30) String firstname,
				@Size(min = 1, max = 50) String mail, @Size(min = 1, max = 30) String password) {
			this.id = id;
			this.name = name;
			this.firstname = firstname;
			this.mail = mail;
			this.password = password;
		}
		
		
}
