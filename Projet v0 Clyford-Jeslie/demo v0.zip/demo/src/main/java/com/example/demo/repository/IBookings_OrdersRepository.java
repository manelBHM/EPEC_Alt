package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model_metier.Bookings_Orders;
@Repository
public interface IBookings_OrdersRepository extends JpaRepository<Bookings_Orders,Long>{

}
