/*package com.example.demo.api;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model_metier.Bookings_Orders;
import com.example.demo.repository.IBookings_OrdersRepository;
@CrossOrigin(value="*")
@RestController
@RequestMapping(value="/api")
public class Bookings_OrdersController {

	@Autowired
	IBookings_OrdersRepository nouveau;
	
	
	@GetMapping(value = "/premium") // @Tracable
	public List<Bookings_Orders> getMyOrder() {
	    return nouveau.findAll();
		
	    
	 
	    } 

	  @GetMapping (value="/annonce/{id}")
			public ResponseEntity<?> getMyOrder(@PathVariable Long id) {
				Optional<Bookings_Orders> mescommandes = nouveau.findById(id);
				if(!mescommandes.isPresent())
				return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
				return ResponseEntity.ok(mescommandes); }
}

*/




