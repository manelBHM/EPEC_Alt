package Test.fizz_buzz;



public class App 
{
    public static void main( String[] args ) throws InterruptedException
    {
    	Fizz_Buzz fzbz = new Fizz_Buzz();
    	
    	fzbz.fizzBuzz();
    	
    }
}
